package br.com.fiap.motos.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
@Table(name = "TB_ACESSORIO")
public class Acessorio {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
            generator = "SQ_ACESSORIO")
    @SequenceGenerator(name = "SQ_ACESSORIO",
            sequenceName = "SQ_ACESSORIO",
            initialValue = 1,
            allocationSize = 1
    )
    @Column(name = "ID_ACESSORIO")
    private Long id;

    @Column(name = "NM_ACESSORIO")
    private String nome;

    @Column(name = "PRECO")
    private Double preco;


    //@OneToOne(
    //        fetch = FetchType.EAGER,
    //        cascade = {CascadeType.MERGE, CascadeType.PERSIST}
    //)
    //@/JoinColumn(
    //name = "ENDERECO",
    //        referencedColumnName = "ID_ENDERECO",
    //        foreignKey = @ForeignKey(
    //                name = "FK_ENDERECO_CLIENTE"
    //        )
    //)


}
