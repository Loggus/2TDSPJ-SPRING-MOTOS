package br.com.fiap.motos.resource;

public class LojaResource {
}
