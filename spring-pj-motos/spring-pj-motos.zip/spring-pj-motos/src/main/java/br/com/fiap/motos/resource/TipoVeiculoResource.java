package br.com.fiap.motos.resource;

import br.com.fiap.motos.entity.Acessorio;
import br.com.fiap.motos.entity.TipoDeVeiculo;
import br.com.fiap.motos.repository.TipoDeVeiculoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/TipoVeiculoResource")
public class TipoVeiculoResource {

    @Autowired
    TipoDeVeiculoRepository repo;

    @GetMapping
    public List<TipoDeVeiculo> findAll() {return repo.findAll();}

    @GetMapping(value = "/{id}")
    public TipoDeVeiculo findAll(@PathVariable("id") Long id) {
        var ret = repo.findById(id);
        return ret.get();
    }

    @PostMapping("/TipoDeVeiculo")
    public TipoDeVeiculo savePost(@RequestBody TipoDeVeiculo requestBody) {
        var save = repo.save(requestBody);
        return save;
    }


}
