package br.com.fiap.motos.resource;

import br.com.fiap.motos.entity.Veiculo;
import br.com.fiap.motos.repository.VeiculoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping(value = "/veiculos")
public class VeiculoResource {
    @Autowired
    private VeiculoRepository repo;

    @GetMapping
    public List<Veiculo> findAll() {return repo.findAll();}

    @GetMapping(value = "/{id}")
    public Veiculo findAll(@PathVariable("id") Long id) {
        var ret = repo.findById(id);
        return ret.get();
    }
}
